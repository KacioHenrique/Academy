import UIKit
import MapKit
class ViewController: UIViewController {
    let initialLocation = CLLocation(latitude: 21.282778, longitude: -157.829444)//defino coordenas inicias que é waikki
    let regionRadius: CLLocationDistance = 1000 //distância  de cima que eu quero ver
    @IBOutlet weak var mapa: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        centerMapOnLocation(location: initialLocation)
        mapa.delegate = self
        let artwork = Artwork(title: "King David Kalakaua",
                              locationName: "Waikiki Gateway Park",
                              discipline: "Sculpture",
                              coordinate: CLLocationCoordinate2D(latitude: 21.282778, longitude: -157.831661))
        mapa.addAnnotation(artwork)//adiona uma anotação que é dada por ArtWork
}
    //passo minha coordenas para essa função
    func centerMapOnLocation(location: CLLocation){
        let coorddinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)//aqui eu chamo o metodo coordinate e zoom da latitude e da longitude
            mapa.setRegion(coorddinateRegion,animated: true)//por trás dos panos eu dou um zom para aquele lugar ,faça que a região mostrada no mapa seja
    }
}

//isso aqui é uma extensão
extension ViewController: MKMapViewDelegate {
    // 1 é chamado para cada anotação adicionada no mapa
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // 2 é da minha classe ? se não retorno qual quer coisa
        guard let annotation = annotation as? Artwork else { return nil }
        // 3
        let identifier = "marker"
        var view: MKMarkerAnnotationView //para fazer marcadores aparecerem
        // 4 isso é bem importante se for reutilizavél
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            // 5
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        return view
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 calloutAccessoryControlTapped control: UIControl) {
        let location = view.annotation as! Artwork
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        location.mapItem().openInMaps(launchOptions: launchOptions)
    }
}

