import UIKit
import MapKit
import CoreLocation
class ViewController: UIViewController {
    let initialLocation = CLLocation(latitude:-8.0523537, longitude: -34.950548)//defino coordenas inicias que é waikki
    let regionRadius: CLLocationDistance = 1000 //distância  de cima que eu quero ver
    @IBOutlet weak var mapa: MKMapView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var buscar: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        label.text = ""
        buscar.addTarget(self, action:#selector(pesquisar), for: .touchUpInside)
        mapa.delegate = self
        let locationManeger = CLLocationManager()
        locationManeger.requestAlwaysAuthorization()
        self.mapa.showsUserLocation = true
        self.mapa.register(ArtworkMarkerView.self,
                         forAnnotationViewWithReuseIdentifier:"marker")
        let artwork:[Artwork] = [Artwork(title: "eletrônico",
                              locationName: "seu zé",
                              discipline: "Monument",
                              coordinate: CLLocationCoordinate2D(latitude: -8.0523537, longitude: -34.950648)),Artwork(title: "eletrônico",
                                                                                                                       locationName: "Cooperativa Emaus",
                                                                                                                       discipline: "Sculpture",
                                                                                                                       coordinate: CLLocationCoordinate2D(latitude: -8.0523540 ,longitude:  -34.9536271)),Artwork(title: "eletrônico",
                                                                                                                                                                                                                  locationName: "eltro back",
                                                                                                                                                                                                                  discipline: "Sculpture",
                                                                                                                                                                                                                  coordinate: CLLocationCoordinate2D(latitude: -8.0450367, longitude: -34.9479684)),Artwork(title: "eletrônico",
                                                                                                                                                                                                                                                                                                            locationName: "seu marcos",
                                                                                                                                                                                                                                                                                                            discipline: "Plaque",
                                                                                                                                                                                                                                                                                                            coordinate: CLLocationCoordinate2D(latitude: -8.049316, longitude: -34.945712)),Artwork(title: "eletrônico",
                                                                                                                                                                                                                                                                                                                                                                                                    locationName: "seu zé",
                                                                                                                                                                                                                                                                                                                                                                                                    discipline: "Plaque",
                                                                                                                                                                                                                                                                                                                                                                                                    coordinate: CLLocationCoordinate2D(latitude: -8.0475667, longitude: -34.9476402)),Artwork(title: "eletrônico",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              locationName: "seu caio gomes",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              discipline: "Plaque",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              coordinate: CLLocationCoordinate2D(latitude: -8.0444704, longitude: -34.9491541))]
       /* mapa.addAnnotation(artwork[0])//adiona uma anotação que é dada por ArtWork
        mapa.addAnnotation(artwork[1])
        mapa.addAnnotation(artwork[2])
        mapa.addAnnotation(artwork[3])
    */
       addAnote(artwork)
    }
    //passo minha coordenas para essa função
    @objc func pesquisar(){
        centerMapOnLocation(location: initialLocation)
        
        animation()
    }
    func centerMapOnLocation(location: CLLocation){
        let coorddinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)//aqui eu chamo o metodo coordinate e zoom da latitude e da longitude
            mapa.setRegion(coorddinateRegion,animated: true)//por trás dos panos eu dou um zom para aquele lugar ,faça que a região mostrada no mapa seja
    }
    func animation(){
        UIView.animate(withDuration: 4.0, animations: { () -> Void in
           self.label.text = "existe 10 lugares perto da sua rota"
            self.label.frame.origin.y=self.view.frame.maxY/3 - 50
        })
    }
    //adiciono as anotações na tela
    func addAnote(_ art:[Artwork]){
        var i = 0
        while i < art.count {
            mapa.addAnnotation(art[i])
            i+=1
        }
    }
 }
//Este método é chamado todas as vezes que o nível de permissão da localização é alterado


//isso aqui é uma extensão
extension ViewController: MKMapViewDelegate {
    // 1 é chamado para cada anotação adicionada no mapa
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // 2 é da minha classe ? se não retorno qual quer coisa
        guard let annotation = annotation as? Artwork else { return nil }
        // 3
        let identifier = "marker"
        var view: MKMarkerAnnotationView //para fazer marcadores aparecerem
        // 4 isso é bem importante se for reutilizavél
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            // 5
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        return view
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 calloutAccessoryControlTapped control: UIControl) {
        let location = view.annotation as! Artwork
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        location.mapItem().openInMaps(launchOptions: launchOptions)
    }

}
